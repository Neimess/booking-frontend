import React from 'react';

export default function AdminPage() {
  return (
    <div>
      <h2>Admin Panel</h2>
      <p>Coming soon...</p>
    </div>
  );
}