// api/index.js
import { fetchMyBookings, cancelBooking } from './bookingsApi';
export default { fetchMyBookings, cancelBooking }; 