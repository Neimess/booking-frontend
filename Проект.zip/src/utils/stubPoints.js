export const stubPoints = [
    { id: 1, label: 'Тестовая точка 1', lat: 55.751244, lng: 37.618423 },
    { id: 2, label: 'Тестовая точка 2', lat: 48.856613, lng: 2.352222 },
    { id: 3, label: 'Тестовая точка 3', lat: 51.507351, lng: -0.127758 },
  ];